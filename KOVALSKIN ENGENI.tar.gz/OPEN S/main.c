#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "src/scene_manager.hpp"

// Variáveis globais para Input e FPS
bool input_lock = false;
double lastFPSUpdate = 0.0;
int frameCount = 0;

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    resize_engine(width, height);
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS) {
        if (key == GLFW_KEY_UP)    inject_input(1); 
        if (key == GLFW_KEY_DOWN)  inject_input(2); 
        if (key == GLFW_KEY_ENTER) inject_input(3); 
        if (key == GLFW_KEY_ESCAPE) glfwSetWindowShouldClose(window, true);
    }
}

void process_input_logic() {
    if (!glfwJoystickPresent(GLFW_JOYSTICK_1)) return;

    GLFWgamepadstate state;
    if (glfwGetGamepadState(GLFW_JOYSTICK_1, &state)) {
        float axisY = state.axes[GLFW_GAMEPAD_AXIS_LEFT_Y];
        if (!input_lock) {
            if (axisY < -0.5f || state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_UP]) {
                inject_input(1);
                input_lock = true;
            } else if (axisY > 0.5f || state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_DOWN]) {
                inject_input(2);
                input_lock = true;
            } else if (state.buttons[GLFW_GAMEPAD_BUTTON_A]) {
                inject_input(3);
                input_lock = true;
            }
        }
        if (axisY > -0.2f && axisY < 0.2f && 
            !state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_UP] && 
            !state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_DOWN] &&
            !state.buttons[GLFW_GAMEPAD_BUTTON_A]) {
            input_lock = false;
        }
    } else {
        int axesCount, buttonCount;
        const float* axes = glfwGetJoystickAxes(GLFW_JOYSTICK_1, &axesCount);
        const unsigned char* buttons = glfwGetJoystickButtons(GLFW_JOYSTICK_1, &buttonCount);
        if (axesCount >= 2 && !input_lock) {
            if (axes[1] < -0.5f) { inject_input(1); input_lock = true; }
            else if (axes[1] > 0.5f) { inject_input(2); input_lock = true; }
        }
        if (buttonCount >= 1 && !input_lock) {
            if (buttons[0] == GLFW_PRESS || (buttonCount > 1 && buttons[1] == GLFW_PRESS)) {
                inject_input(3);
                input_lock = true;
            }
        }
        if (axesCount >= 2 && axes[1] > -0.2f && axes[1] < 0.2f && (buttonCount > 0 && buttons[0] == GLFW_RELEASE)) {
            input_lock = false;
        }
    }
}

void update_fps_counter(GLFWwindow* window, double currentTime) {
    double timeDiff = currentTime - lastFPSUpdate;
    frameCount++;

    if (timeDiff >= 1.0) {
        char title[128];
        double fps = (double)frameCount / timeDiff;
        double msPerFrame = 1000.0 / fps;

        sprintf(title, "Kovalskin Edition | FPS: %.1f | %.3f ms", fps, msPerFrame);
        glfwSetWindowTitle(window, title);

        frameCount = 0;
        lastFPSUpdate = currentTime;
    }
}

int main() {
    if (!glfwInit()) return -1;

    if (glfwJoystickPresent(GLFW_JOYSTICK_1)) {
        printf("[INFO] Controle detectado: %s\n", glfwGetJoystickName(GLFW_JOYSTICK_1));
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(1600, 900, "Kovalskin Edition", NULL, NULL);
    if (!window) { glfwTerminate(); return -1; }
    
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window, key_callback);

    // --- CONFIGURAÇÃO DO VSYNC ---
    // 0 = Desativado (FPS ilimitado)
    // 1 = Ativado (Sincronizado com o monitor, ex: 60 FPS)
    glfwSwapInterval(0); 

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) return -1;

    if (!init_engine()) {
        system("zenity --error --title='Kovalskin Engine' --text='Erro de recursos.'");
        glfwTerminate();
        return -1;
    }

    int w, h;
    glfwGetFramebufferSize(window, &w, &h);
    resize_engine(w, h);

    double lastTime = glfwGetTime();
    lastFPSUpdate = lastTime;

    while (!glfwWindowShouldClose(window)) {
        double currentTime = glfwGetTime();
        float deltaTime = (float)(currentTime - lastTime);
        lastTime = currentTime;

        update_fps_counter(window, currentTime);
        glfwPollEvents();
        process_input_logic();

        update_engine(deltaTime);
        render_engine();

        glfwSwapBuffers(window);
    }

    glfwTerminate();
    return 0;
}