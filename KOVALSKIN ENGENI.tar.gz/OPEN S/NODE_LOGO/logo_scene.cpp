#include <glad/glad.h>
#include "../src/scene_manager.hpp"
#include <GLFW/glfw3.h> // Para o glfwGetTime se necessário

class LogoScene : public Scene {
    float timer = 0.0f;
    std::string logo_text = "KOVALSKIN EDITION";
public:
    void update(float dt) override {
        timer += dt;
        // Após 4 segundos, dispara o gatilho para mudar para o menu
        if (timer > 2.0f) {
            switch_scene(SCENE_MENU);
        }
    }

    void render() override {
        glClearColor(0.01f, 0.01f, 0.02f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        float scale = 1.0f;
        // Centraliza o texto usando a função global da engine
        float x = (screenW - get_text_width(logo_text, scale)) / 2.0f;
        float y = (screenH / 2.0f);
        
        render_text(logo_text, x, y, scale, glm::vec3(1.0f)); 
    }
};

// Gatilho que o Scene Manager vai encontrar
extern "C" Scene* create_logo_scene() {
    return new LogoScene();
}