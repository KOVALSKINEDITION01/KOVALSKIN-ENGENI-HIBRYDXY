#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include "scene_manager.hpp"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <string>

struct Character {
    unsigned int TextureID; 
    glm::ivec2   Size;      
    glm::ivec2   Bearing;   
    unsigned int Advance;   
};

std::map<char, Character> Characters;
unsigned int textVAO, textVBO, textShader;
float screenW = 1600.0f, screenH = 900.0f;
Scene* current_scene = nullptr;

bool check_file(const std::string& path) {
    std::ifstream f(path.c_str());
    return f.good();
}

unsigned int loadShader(const char* vPath, const char* fPath) {
    std::string vCode, fCode;
    std::ifstream vFile(vPath), fFile(fPath);
    std::stringstream vStream, fStream;
    vStream << vFile.rdbuf(); fStream << fFile.rdbuf();
    vCode = vStream.str(); fCode = fStream.str();
    const char* vPtr = vCode.c_str();
    const char* fPtr = fCode.c_str();
    unsigned int vertex = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertex, 1, &vPtr, NULL);
    glCompileShader(vertex);
    unsigned int fragment = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragment, 1, &fPtr, NULL);
    glCompileShader(fragment);
    unsigned int program = glCreateProgram();
    glAttachShader(program, vertex);
    glAttachShader(program, fragment);
    glLinkProgram(program);
    glDeleteShader(vertex); glDeleteShader(fragment);
    return program;
}

void init_freetype(const char* fontPath) {
    FT_Library ft;
    FT_Init_FreeType(&ft);
    FT_Face face;
    FT_New_Face(ft, fontPath, 0, &face);
    FT_Set_Pixel_Sizes(face, 0, 100); 
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1); 
    for (unsigned char c = 0; c < 128; c++) {
        FT_Load_Char(face, c, FT_LOAD_RENDER);
        unsigned int texture;
        glGenTextures(1, &texture);
        glBindTexture(GL_TEXTURE_2D, texture);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, face->glyph->bitmap.width, face->glyph->bitmap.rows, 0, GL_RED, GL_UNSIGNED_BYTE, face->glyph->bitmap.buffer);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        Character character = { texture, glm::ivec2(face->glyph->bitmap.width, face->glyph->bitmap.rows), glm::ivec2(face->glyph->bitmap_left, face->glyph->bitmap_top), (unsigned int)face->glyph->advance.x };
        Characters.insert(std::pair<char, Character>(c, character));
    }
    FT_Done_Face(face); FT_Done_FreeType(ft);
    glGenVertexArrays(1, &textVAO);
    glGenBuffers(1, &textVBO);
    glBindVertexArray(textVAO);
    glBindBuffer(GL_ARRAY_BUFFER, textVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), 0);
}

void render_text(std::string text, float x, float y, float scale, glm::vec3 color) {
    glUseProgram(textShader);
    glUniform3f(glGetUniformLocation(textShader, "textColor"), color.x, color.y, color.z);
    glm::mat4 projection = glm::ortho(0.0f, screenW, 0.0f, screenH);
    glUniformMatrix4fv(glGetUniformLocation(textShader, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
    glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(textVAO);
    for (auto c = text.begin(); c != text.end(); c++) {
        Character ch = Characters[*c];
        float xpos = x + ch.Bearing.x * scale;
        float ypos = y - (ch.Size.y - ch.Bearing.y) * scale;
        float w = ch.Size.x * scale;
        float h = ch.Size.y * scale;
        float vertices[6][4] = {
            { xpos, ypos + h, 0.0f, 0.0f }, { xpos, ypos, 0.0f, 1.0f }, { xpos + w, ypos, 1.0f, 1.0f },
            { xpos, ypos + h, 0.0f, 0.0f }, { xpos + w, ypos, 1.0f, 1.0f }, { xpos + w, ypos + h, 1.0f, 0.0f }
        };
        glBindTexture(GL_TEXTURE_2D, ch.TextureID);
        glBindBuffer(GL_ARRAY_BUFFER, textVBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices); 
        glDrawArrays(GL_TRIANGLES, 0, 6);
        x += (ch.Advance >> 6) * scale; 
    }
}

float get_text_width(std::string text, float scale) {
    float width = 0.0f;
    for (auto c = text.begin(); c != text.end(); c++) width += (Characters[*c].Advance >> 6) * scale;
    return width;
}

extern "C" {
    extern Scene* create_logo_scene();
    extern Scene* create_menu_scene();

    void switch_scene(int id) {
        if(current_scene) delete current_scene;
        if(id == SCENE_LOGO) current_scene = create_logo_scene();
        else current_scene = create_menu_scene();
    }

    bool init_engine() {
        if (!check_file("src/shaders/text.vs") || !check_file("src/shaders/text.fs") || !check_file("assets/fonts/logo_font.otf")) return false; 
        glEnable(GL_BLEND); 
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        textShader = loadShader("src/shaders/text.vs", "src/shaders/text.fs");
        init_freetype("assets/fonts/logo_font.otf");
        switch_scene(SCENE_LOGO);
        return true;
    }

    void update_engine(float dt) { if(current_scene) current_scene->update(dt); }
    void render_engine() { if(current_scene) current_scene->render(); }
    void resize_engine(int w, int h) { screenW = (float)w; screenH = (float)h; glViewport(0,0,w,h); }
    
    // IMPLEMENTAÇÃO DA INJEÇÃO DE INPUT
    void inject_input(int action) {
        if (current_scene) current_scene->on_input(action);
    }
}