#ifndef SCENE_MANAGER_HPP
#define SCENE_MANAGER_HPP

#ifdef __cplusplus
#include <string>
#include <glm/glm.hpp>

class Scene {
public:
    virtual ~Scene() {}
    virtual void update(float dt) = 0;
    virtual void render() = 0;
    virtual void on_input(int action) {} // 1: Cima, 2: Baixo, 3: Confirmar
};

void render_text(std::string text, float x, float y, float scale, glm::vec3 color);
float get_text_width(std::string text, float scale);
extern float screenW, screenH;

extern "C" {
#endif

#include <stdbool.h>

bool init_engine();
void update_engine(float dt);
void render_engine();
void resize_engine(int width, int height);
void inject_input(int action); // Ponte entre C e C++

#define SCENE_LOGO 0
#define SCENE_MENU 1
void switch_scene(int id);

#ifdef __cplusplus
}
#endif
#endif