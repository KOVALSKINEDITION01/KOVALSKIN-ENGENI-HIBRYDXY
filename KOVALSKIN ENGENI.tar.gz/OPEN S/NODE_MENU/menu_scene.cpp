#include <glad/glad.h>
#include "../src/scene_manager.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

class MenuScene : public Scene {
private:
    std::string title = "KOVALSKIN ENGINE";
    std::vector<std::string> options = {"1. INICIAR", "2. CONFIGURACOES", "3. SAIR"};
    int selected_index = 0; // Índice atual da seleção
    
    glm::vec3 bg_color = glm::vec3(0.0f);
    glm::vec3 title_color = glm::vec3(1.0f);
    float anim_speed = 300.0f;
    float fade_duration = 1.0f;

    float animTimer = 0.0f;
    float menuAlpha = 0.0f;
    float offsetX = -300.0f;

    void load_style(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) return;
        std::string line, key;
        float value;
        while (std::getline(file, line)) {
            if (line.empty() || line[0] == '#') continue;
            std::replace(line.begin(), line.end(), ':', ' ');
            std::stringstream ss(line);
            ss >> key >> value;
            if (key == "bg_r") bg_color.r = value;
            else if (key == "bg_g") bg_color.g = value;
            else if (key == "bg_b") bg_color.b = value;
            else if (key == "title_r") title_color.r = value;
            else if (key == "title_g") title_color.g = value;
            else if (key == "title_b") title_color.b = value;
            else if (key == "anim_speed") anim_speed = value;
            else if (key == "fade_duration") fade_duration = value;
        }
    }

public:
    MenuScene() {
        load_style("NODE_MENU/style.cfg");
    }

    // Gerencia a lógica de pressionar teclas
    void on_input(int action) override {
        if (action == 1) { // Cima
            selected_index--;
            if (selected_index < 0) selected_index = options.size() - 1;
        } 
        else if (action == 2) { // Baixo
            selected_index++;
            if (selected_index >= (int)options.size()) selected_index = 0;
        } 
        else if (action == 3) { // Confirmar
            std::cout << "Acao executada: " << options[selected_index] << std::endl;
            if (selected_index == 2) exit(0); // Fecha o jogo se for "Sair"
        }
    }

    void update(float dt) override {
        animTimer += dt;
        menuAlpha = std::min(animTimer / fade_duration, 1.0f);
        if (offsetX < 0) {
            offsetX += dt * anim_speed;
            if (offsetX > 0) offsetX = 0;
        }
    }

    void render() override {
        glClearColor(bg_color.r, bg_color.g, bg_color.b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        float x_base = 100.0f + offsetX;
        float y_title = screenH - 150.0f;

        render_text(title, x_base, y_title, 0.9f, title_color * menuAlpha);

        for (size_t i = 0; i < options.size(); i++) {
            float y_opt = y_title - 150.0f - (i * 70.0f);
            float optAlpha = std::min(std::max(animTimer - 0.5f, 0.0f), 1.0f);
            
            // Destaque visual: Amarelo para selecionado, Branco para os outros
            glm::vec3 color = ((int)i == selected_index) ? glm::vec3(1.0f, 1.0f, 0.0f) : glm::vec3(1.0f);
            
            render_text(options[i], x_base + 20.0f, y_opt, 0.5f, color * optAlpha);
        }
    }
};

extern "C" Scene* create_menu_scene() {
    return new MenuScene();
}