#include <glad/glad.h>
#include "../src/SUBKERNEL.hpp"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <fstream>
#include <string>

class PilarScene : public Scene {
private:
    // Dados da Câmera que virão do ZIG
    glm::vec3 cameraPos;
    glm::vec3 cameraTarget;
    glm::vec3 skyColor;

    void load_zig_data(const std::string& path) {
        std::ifstream file(path);
        if (!file.is_open()) {
            std::cerr << "ERRO: Nao foi possivel abrir o arquivo " << path << std::endl;
            return;
        }

        std::string line;
        while (std::getline(file, line)) {
            // Ignora comentários ou linhas vazias
            if (line.empty() || line[0] == '#') continue;

            // Parser simples para as coordenadas
            if (line.find("pos_x =") != std::string::npos) cameraPos.x = std::stof(line.substr(line.find("=") + 1));
            if (line.find("pos_y =") != std::string::npos) cameraPos.y = std::stof(line.substr(line.find("=") + 1));
            if (line.find("pos_z =") != std::string::npos) cameraPos.z = std::stof(line.substr(line.find("=") + 1));
            
            if (line.find("sky_r =") != std::string::npos) skyColor.r = std::stof(line.substr(line.find("=") + 1));
            if (line.find("sky_g =") != std::string::npos) skyColor.g = std::stof(line.substr(line.find("=") + 1));
            if (line.find("sky_b =") != std::string::npos) skyColor.b = std::stof(line.substr(line.find("=") + 1));
        }
        file.close();
        std::cout << "ZIG carregado com sucesso!" << std::endl;
    }

public:
    PilarScene() {
        // Inicializa com valores padrão
        cameraPos = glm::vec3(0, 0, 5);
        skyColor = glm::vec3(0, 0, 0);

        // Carrega os dados reais do arquivo ZIG
        load_zig_data("NODE_PLANOTERRENO/pilarprimeiro_scene.ZIG");
    }

    void update(float dt) override {
        // Aqui você colocará a lógica de movimento da câmera depois
    }

    void render() override {
        // Aplica a cor do céu vinda do ZIG
        glClearColor(skyColor.r, skyColor.g, skyColor.b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Feedback visual na tela
        render_text("MODO: EXPLORACAO (ZIG DATA)", 20, screenH - 50, 0.4f, glm::vec3(1, 1, 1));
        
        char posMsg[64];
        sprintf(posMsg, "Camera ZIG: %.1f, %.1f, %.1f", cameraPos.x, cameraPos.y, cameraPos.z);
        render_text(posMsg, 20, screenH - 100, 0.35f, glm::vec3(0.7f, 0.7f, 1.0f));
    }
};

// Exporta a função para o Scene Manager
extern "C" Scene* create_game_scene() {
    return new PilarScene();
}