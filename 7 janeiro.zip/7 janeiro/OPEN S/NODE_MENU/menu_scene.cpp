#include "../src/SUBKERNEL.hpp"
#include <vector>
#include <string>
#include <glm/glm.hpp>

class MenuScene : public Scene {
private:
    std::vector<std::string> options;
    size_t selectedIndex;
    float menuYStart;
    float spacing;

public:
    MenuScene() {
        options = {"NOVO JOGO", "LOAD", "OPCOES", "CREDITOS", "SAIR"};
        selectedIndex = 0;
        menuYStart = 400.0f; // Posição Y da primeira opção
        spacing = 80.0f;     // Espaço entre cada linha
    }

    void update(float dt) override {
        // Lógica de animação pode entrar aqui
    }

    void render() override {
        for (size_t i = 0; i < options.size(); i++) {
            // Cor: Amarelo se selecionado, cinza claro se não
            glm::vec3 color = (i == selectedIndex) ? 
                              glm::vec3(1.0f, 1.0f, 0.0f) : 
                              glm::vec3(0.8f, 0.8f, 0.8f);

            // Escala: Um pouco maior se selecionado
            float scale = (i == selectedIndex) ? 1.0f : 0.7f;
            
            // Centraliza o texto horizontalmente usando a largura da string
            float textWidth = get_text_width(options[i], scale);
            float xPos = (screenW - textWidth) / 2.0f;
            
            // Y aumenta para baixo no sistema de coordenadas 0-topo
            float yPos = menuYStart + (i * spacing);

            render_text(options[i], xPos, yPos, scale, color);
        }
    }

    void on_input(int action) override {
        if (action == 1) { // COMANDO: CIMA
            if (selectedIndex == 0) {
                selectedIndex = options.size() - 1;
            } else {
                selectedIndex--;
            }
        }
        else if (action == 2) { // COMANDO: BAIXO
            selectedIndex++;
            if (selectedIndex >= options.size()) {
                selectedIndex = 0;
            }
        }
        else if (action == 3) { // COMANDO: CONFIRMAR
            if (options[selectedIndex] == "SAIR") {
                // Adicione aqui a lógica para fechar o jogo se necessário
            } else if (options[selectedIndex] == "NOVO JOGO") {
                switch_scene(SCENE_GAME);
            }
        }
    }
};

// Função externa para o Scene Manager criar esta cena
extern "C" Scene* create_menu_scene() {
    return new MenuScene();
}