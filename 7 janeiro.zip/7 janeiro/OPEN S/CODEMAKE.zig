sudo apt update
sudo apt install build-essential libglfw3-dev libgl1-mesa-dev libglm-dev