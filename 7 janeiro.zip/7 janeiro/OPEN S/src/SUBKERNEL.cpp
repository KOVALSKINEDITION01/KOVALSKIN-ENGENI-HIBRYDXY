#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "src/SUBKERNEL.hpp"
#include "src/font_renderer.hpp"
#include <glm/glm.hpp>
#include <iostream>
#include <fstream>

float screenW = 1600.0f, screenH = 900.0f;
Scene* current_scene = nullptr;

void update_screen_dims() {
    FontRenderer::screenWidth = screenW;
    FontRenderer::screenHeight = screenH;
}

bool check_file(const std::string& path) {
    std::ifstream f(path.c_str());
    return f.good();
}

void render_text(std::string text, float x, float y, float scale, glm::vec3 color) {
    g_fontRenderer.renderText(text, x, y, scale, color);
}

float get_text_width(std::string text, float scale) {
    return g_fontRenderer.getTextWidth(text, scale);
}

extern "C" {
    extern Scene* create_logo_scene();
    extern Scene* create_menu_scene();
    extern Scene* create_game_scene();
    
    void switch_scene(int id) {
        if(current_scene) delete current_scene;
        if(id == SCENE_LOGO) current_scene = create_logo_scene();
        else if(id == SCENE_MENU) current_scene = create_menu_scene();
        else if(id == SCENE_GAME) current_scene = create_game_scene();
    }

    bool init_engine() {
        g_fontRenderer.init();
        if (!check_file("assets/fonts/logo_font.ttf")) return false; 
        glEnable(GL_BLEND); 
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        if (!g_fontRenderer.loadFont("default", "assets/fonts/logo_font.ttf", 128.0f)) return false;
        update_screen_dims();
        switch_scene(SCENE_LOGO);
        return true;
    }

    void update_engine(float dt) { if(current_scene) current_scene->update(dt); }
    void render_engine() { 
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        if(current_scene) current_scene->render(); 
    }
    void resize_engine(int w, int h) { 
        screenW = (float)w; screenH = (float)h; 
        glViewport(0, 0, w, h);
        update_screen_dims();
    }
    void inject_input(int action) { if (current_scene) current_scene->on_input(action); }
}