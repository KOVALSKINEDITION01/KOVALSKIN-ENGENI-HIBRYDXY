#ifndef FONT_RENDERER_HPP
#define FONT_RENDERER_HPP

#include <glm/glm.hpp>
#include <string>
#include <map>
#include <vector>

struct stbtt_fontinfo;
struct GlyphInfo {
    glm::ivec2   size;
    glm::ivec2   bearing;
    unsigned int advance;
    glm::vec2    uv0, uv1;
};

class FontRenderer {
private:
    struct FontData {
        std::map<int, GlyphInfo> glyphs;
        unsigned int textureAtlas;
        int atlasWidth, atlasHeight;
        float pixelHeight;
        stbtt_fontinfo* fontInfo;
        unsigned char* fontBuffer;
        
        FontData() : textureAtlas(0), atlasWidth(0), atlasHeight(0), 
                    pixelHeight(0), fontInfo(nullptr), fontBuffer(nullptr) {}
        
        ~FontData();
        FontData(const FontData&) = delete;
        FontData& operator=(const FontData&) = delete;
        FontData(FontData&& other) noexcept;
        FontData& operator=(FontData&& other) noexcept;
    };
    
    std::map<std::string, FontData> fonts;
    unsigned int textVAO, textVBO, textShader;
    FontData* currentFont;
    
    void loadFontData(FontData& font, const std::string& path, float pixelHeight);
    void createAtlas(FontData& font, float pixelHeight);
    
public:
    FontRenderer();
    ~FontRenderer();
    
    void init();
    bool loadFont(const std::string& name, const std::string& path, float pixelHeight = 128.0f);
    void useFont(const std::string& name);
    void renderText(const std::string& text, float x, float y, float scale, const glm::vec3& color = glm::vec3(1.0f));
    float getTextWidth(const std::string& text, float scale);
    
    static float screenWidth, screenHeight;
};

extern FontRenderer g_fontRenderer;

#endif