#include "PLATFORM.h"
#include <GLFW/glfw3.h>
#include <stdio.h>
#include <stdlib.h>

void KOVALSKIN_PLATFORM_INIT(WINDOW_CONFIG* config) {
    if (!glfwInit()) {
        fprintf(stderr, "[KOVALSKIN] ERRO: Falha ao inicializar GLFW\n");
        exit(EXIT_FAILURE);
    }
}

void KOVALSKIN_PLATFORM_CREATE_WINDOW(WINDOW_CONFIG* config) {
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    
    config->window = glfwCreateWindow(
        config->width, 
        config->height, 
        config->title, 
        NULL, 
        NULL
    );
    
    if (!config->window) {
        fprintf(stderr, "[KOVALSKIN] ERRO: Falha ao criar janela\n");
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    
    glfwMakeContextCurrent((GLFWwindow*)config->window);
}

void KOVALSKIN_PLATFORM_DESTROY(WINDOW_CONFIG* config) {
    if (config->window) {
        glfwDestroyWindow((GLFWwindow*)config->window);
    }
    glfwTerminate();
}

double KOVALSKIN_PLATFORM_GET_TIME(void) {
    return glfwGetTime();
}

void KOVALSKIN_PLATFORM_SET_VSYNC(int enabled) {
    glfwSwapInterval(enabled);
}

int KOVALSKIN_PLATFORM_WINDOW_SHOULD_CLOSE(WINDOW_CONFIG* config) {
    return glfwWindowShouldClose((GLFWwindow*)config->window);
}

void KOVALSKIN_PLATFORM_POLL_EVENTS(WINDOW_CONFIG* config) {
    glfwPollEvents();
}

void KOVALSKIN_PLATFORM_SWAP_BUFFERS(WINDOW_CONFIG* config) {
    glfwSwapBuffers((GLFWwindow*)config->window);
}

void KOVALSKIN_PLATFORM_SET_WINDOW_TITLE(KOVALSKIN_WINDOW window, const char* title) {
    glfwSetWindowTitle((GLFWwindow*)window, title);
}