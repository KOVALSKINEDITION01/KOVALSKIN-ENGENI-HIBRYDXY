#ifndef KOVALSKIN_PLATFORM_H
#define KOVALSKIN_PLATFORM_H

#ifdef __linux__
    #include <GLFW/glfw3.h>
    typedef GLFWwindow* KOVALSKIN_WINDOW;
#else
    typedef void* KOVALSKIN_WINDOW;
#endif

typedef struct {
    int width;
    int height;
    const char* title;
    KOVALSKIN_WINDOW window;
    int vsync;
} WINDOW_CONFIG;

// Funções BÁSICAS da plataforma
void KOVALSKIN_PLATFORM_INIT(WINDOW_CONFIG* config);
void KOVALSKIN_PLATFORM_CREATE_WINDOW(WINDOW_CONFIG* config);
void KOVALSKIN_PLATFORM_DESTROY(WINDOW_CONFIG* config);
double KOVALSKIN_PLATFORM_GET_TIME(void);
void KOVALSKIN_PLATFORM_SET_VSYNC(int enabled);
int KOVALSKIN_PLATFORM_WINDOW_SHOULD_CLOSE(WINDOW_CONFIG* config);
void KOVALSKIN_PLATFORM_POLL_EVENTS(WINDOW_CONFIG* config);
void KOVALSKIN_PLATFORM_SWAP_BUFFERS(WINDOW_CONFIG* config);
void KOVALSKIN_PLATFORM_SET_WINDOW_TITLE(KOVALSKIN_WINDOW window, const char* title);

#endif