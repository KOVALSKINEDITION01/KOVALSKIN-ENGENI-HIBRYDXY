#include <glad/glad.h>
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#define STB_TRUETYPE_IMPLEMENTATION
#define STBTT_STATIC
#include "stb_truetype.h"
#pragma GCC diagnostic pop
#include "font_renderer.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <fstream>






FontRenderer::FontData::~FontData() {
    if (fontInfo) {
        delete fontInfo;
    }
    if (fontBuffer) {
        delete[] fontBuffer;
    }
    if (textureAtlas) {
        glDeleteTextures(1, &textureAtlas);
    }
}



FontRenderer::FontData::FontData(FontData&& other) noexcept 
    : glyphs(std::move(other.glyphs)), 
      textureAtlas(other.textureAtlas), 
      atlasWidth(other.atlasWidth), 
      atlasHeight(other.atlasHeight), 
      pixelHeight(other.pixelHeight), 
      fontInfo(other.fontInfo), 
      fontBuffer(other.fontBuffer) 
{
    other.textureAtlas = 0;
    other.fontInfo = nullptr;
    other.fontBuffer = nullptr;
}




FontRenderer::FontData& FontRenderer::FontData::operator=(FontData&& other) noexcept {
    if (this != &other) {
        // Limpar o que existia antes
        if (fontInfo) {
            delete fontInfo;
        }
        if (fontBuffer) {
            delete[] fontBuffer;
        }
        if (textureAtlas) {
            glDeleteTextures(1, &textureAtlas);
        }

        // Roubar os dados do outro
        glyphs = std::move(other.glyphs);
        textureAtlas = other.textureAtlas;
        atlasWidth = other.atlasWidth;
        atlasHeight = other.atlasHeight;
        pixelHeight = other.pixelHeight;
        fontInfo = other.fontInfo;
        fontBuffer = other.fontBuffer;

        // Resetar o doador
        other.textureAtlas = 0;
        other.fontInfo = nullptr;
        other.fontBuffer = nullptr;
    }
    return *this;
}

float FontRenderer::screenWidth = 1600.0f;
float FontRenderer::screenHeight = 900.0f;

const char* fVS = "#version 460 core\nlayout(location = 0) in vec4 vertex; out vec2 TexCoords; uniform mat4 projection; void main() { gl_Position = projection * vec4(vertex.xy, 0.0, 1.0); TexCoords = vertex.zw; }";
const char* fFS = "#version 460 core\nin vec2 TexCoords; out vec4 color; uniform sampler2D text; uniform vec3 textColor; void main() { color = vec4(textColor, texture(text, TexCoords).r); }";

FontRenderer::FontRenderer() : textVAO(0), textVBO(0), textShader(0), currentFont(nullptr) {}



void FontRenderer::init() {
    unsigned int v = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(v, 1, &fVS, NULL);
    glCompileShader(v);

    unsigned int f = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(f, 1, &fFS, NULL);
    glCompileShader(f);

    textShader = glCreateProgram();
    glAttachShader(textShader, v);
    glAttachShader(textShader, f);
    glLinkProgram(textShader);
    glDeleteShader(v);
    glDeleteShader(f);

    glGenVertexArrays(1, &textVAO);
    glGenBuffers(1, &textVBO);
    glBindVertexArray(textVAO);
    glBindBuffer(GL_ARRAY_BUFFER, textVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), 0);
    glBindVertexArray(0);
}


void FontRenderer::loadFontData(FontData& font, const std::string& path, float pixelHeight) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file.is_open()) return;
    size_t size = file.tellg();
    file.seekg(0, std::ios::beg);
    font.fontBuffer = new unsigned char[size];
    file.read((char*)font.fontBuffer, size);
    font.fontInfo = new stbtt_fontinfo;
    stbtt_InitFont(font.fontInfo, font.fontBuffer, 0);
}

//atlas (mapa da png de letras)

void FontRenderer::createAtlas(FontData& font, float pixelHeight) {
    const int w = 2048, h = 2048;
    unsigned char* data = new unsigned char[w * h]();
    stbtt_packedchar packed[95];
    stbtt_pack_context pc;
    stbtt_PackBegin(&pc, data, w, h, 0, 1, nullptr);
    stbtt_PackFontRange(&pc, font.fontBuffer, 0, pixelHeight, 32, 95, packed);
    stbtt_PackEnd(&pc);

    glGenTextures(1, &font.textureAtlas);
    glBindTexture(GL_TEXTURE_2D, font.textureAtlas);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, w, h, 0, GL_RED, GL_UNSIGNED_BYTE, data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    delete[] data;

    float scale = stbtt_ScaleForPixelHeight(font.fontInfo, pixelHeight);
    for (int i = 0; i < 95; i++) {
        GlyphInfo g;
        g.size = {packed[i].x1 - packed[i].x0, packed[i].y1 - packed[i].y0};
        g.bearing = {packed[i].xoff, packed[i].yoff};
        int adv;
        stbtt_GetCodepointHMetrics(font.fontInfo, i + 32, &adv, 0);
        g.advance = (unsigned int)(adv * scale);
        g.uv0 = {(float)packed[i].x0 / w, (float)packed[i].y0 / h};
        g.uv1 = {(float)packed[i].x1 / w, (float)packed[i].y1 / h};
        font.glyphs[i + 32] = g;
    }
}


void FontRenderer::renderText(const std::string& text, float x, float y, float scale, const glm::vec3& color) {
    if (!currentFont || text.empty()) return;
    glUseProgram(textShader);
    glUniform3fv(glGetUniformLocation(textShader, "textColor"), 1, glm::value_ptr(color));
    
    glm::mat4 proj = glm::ortho(0.0f, screenWidth, screenHeight, 0.0f);
    glUniformMatrix4fv(glGetUniformLocation(textShader, "projection"), 1, GL_FALSE, glm::value_ptr(proj));
    
    glBindTexture(GL_TEXTURE_2D, currentFont->textureAtlas);
    glBindVertexArray(textVAO);

    float curX = x;
    for (unsigned char c : text) {
        if (c < 32 || c > 126) continue;
        GlyphInfo& g = currentFont->glyphs[c];
        float xpos = curX + g.bearing.x * scale;
        float ypos = y + (g.bearing.y + g.size.y) * scale;
        float w = g.size.x * scale;
        float h = g.size.y * scale;

        float verts[6][4] = {
            {xpos,     ypos - h, g.uv0.x, g.uv0.y},
            {xpos,     ypos,     g.uv0.x, g.uv1.y},
            {xpos + w, ypos,     g.uv1.x, g.uv1.y},
            {xpos,     ypos - h, g.uv0.x, g.uv0.y},
            {xpos + w, ypos,     g.uv1.x, g.uv1.y},
            {xpos + w, ypos - h, g.uv1.x, g.uv0.y}
        };
        glBindBuffer(GL_ARRAY_BUFFER, textVBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(verts), verts);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        curX += g.advance * scale;
    }
}

bool FontRenderer::loadFont(const std::string& name, const std::string& path, float pixelHeight) {
    FontData font;
    loadFontData(font, path, pixelHeight);
    if (!font.fontInfo) return false;
    createAtlas(font, pixelHeight);
    fonts[name] = std::move(font);
    if (!currentFont) currentFont = &fonts[name];
    return true;
}

float FontRenderer::getTextWidth(const std::string& text, float scale) {
    if (!currentFont) return 0.0f;
    float w = 0.0f;
    for (unsigned char c : text) {
        if (currentFont->glyphs.count(c)) 
            w += currentFont->glyphs[c].advance * scale;
    }
    return w;
}

void FontRenderer::useFont(const std::string& name) {
    if (fonts.count(name)) currentFont = &fonts[name];
}

FontRenderer::~FontRenderer() { 
    fonts.clear(); 
}

FontRenderer g_fontRenderer;