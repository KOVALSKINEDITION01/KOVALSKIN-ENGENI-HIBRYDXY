#include <glad/glad.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>


#include "src/PLATFORM.h"
#include "src/SUBKERNEL.hpp"




// --- ABSTRAÇÃO DE SISTEMA (Mensagem de Erro Nativa) ---
#ifdef _WIN32
    #include <windows.h>
    #define SHOW_ERROR(msg) MessageBox(NULL, msg, "Kovalskin Engine - Erro Fatal", MB_ICONERROR | MB_OK)
#else
    #define SHOW_ERROR(msg) { \
        char cmd[512]; \
        sprintf(cmd, "zenity --error --title='Kovalskin Engine - Erro Fatal' --text='%s' --width=400", msg); \
        system(cmd); \
    }
#endif



















// VARIÁVEIS GLOBAIS DO KERNEL
WINDOW_CONFIG g_window = {0};
bool input_lock = false;
double lastFPSUpdate = 0.0;
int frameCount = 0;

// CALLBACKS GERENCIADOS PELO KERNEL

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    resize_engine(width, height);
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS) {
        if (key == GLFW_KEY_UP)    inject_input(1);
        if (key == GLFW_KEY_DOWN)  inject_input(2);
        if (key == GLFW_KEY_ENTER) inject_input(3);
        if (key == GLFW_KEY_ESCAPE) glfwSetWindowShouldClose(window, true);
    }
}

// FUNÇÕES DO KERNEL 

void KOVALSKIN_SETUP_CALLBACKS(void) {
    // Configura callbacks diretamente (KERNEL gerencia)
    glfwSetFramebufferSizeCallback((GLFWwindow*)g_window.window, framebuffer_size_callback);
    glfwSetKeyCallback((GLFWwindow*)g_window.window, key_callback);
}

void KOVALSKIN_UPDATE_FPS(void) {
    double currentTime = KOVALSKIN_PLATFORM_GET_TIME();
    double timeDiff = currentTime - lastFPSUpdate;
    frameCount++;
    
    if (timeDiff >= 1.0) {
        char title[128];
        double fps = (double)frameCount / timeDiff;
        double ms_per_frame = 1000.0 / fps;
        
        snprintf(title, sizeof(title), 
                "Kovalskin Edition | FPS: %.1f | %.3f ms", 
                fps, ms_per_frame);
        
        KOVALSKIN_PLATFORM_SET_WINDOW_TITLE(g_window.window, title);
        frameCount = 0;
        lastFPSUpdate = currentTime;
    }
}

void KOVALSKIN_PROCESS_INPUT(void) {
    if (!glfwJoystickPresent(GLFW_JOYSTICK_1)) return;

    GLFWgamepadstate state;
    if (glfwGetGamepadState(GLFW_JOYSTICK_1, &state)) {
        float axisY = state.axes[GLFW_GAMEPAD_AXIS_LEFT_Y];
        if (!input_lock) {
            if (axisY < -0.5f || state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_UP]) { 
                inject_input(1); 
                input_lock = true; 
            }
            else if (axisY > 0.5f || state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_DOWN]) { 
                inject_input(2); 
                input_lock = true; 
            }
            else if (state.buttons[GLFW_GAMEPAD_BUTTON_A]) { 
                inject_input(3); 
                input_lock = true; 
            }
        }
        if (axisY > -0.2f && axisY < 0.2f && 
            !state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_UP] && 
            !state.buttons[GLFW_GAMEPAD_BUTTON_DPAD_DOWN] && 
            !state.buttons[GLFW_GAMEPAD_BUTTON_A]) {
            input_lock = false;
        }
    }
}

//  MAIN 
int main(void) {
    // Configuração inicial
    g_window.width = 1600;
    g_window.height = 900;
    g_window.title = "Kovalskin Edition";
    g_window.vsync = 0;  // VSync OFF
    
    // 1. INICIALIZAR PLATAFORMA
    KOVALSKIN_PLATFORM_INIT(&g_window);
    KOVALSKIN_PLATFORM_CREATE_WINDOW(&g_window);
    
    // 2. CONFIGURAR CALLBACKS (KERNEL gerencia)
    KOVALSKIN_SETUP_CALLBACKS();
    
    // 3. VSync
    KOVALSKIN_PLATFORM_SET_VSYNC(g_window.vsync);
    
    // 4. CARREGAR GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        fprintf(stderr, "[KERNEL] ERRO: Falha ao carregar GLAD\n");
        return -1;
    }
    
    // 5. INICIALIZAR ENGINE
    if (!init_engine()) {
        SHOW_ERROR("Recursos nao carregados (Shaders ou Fontes).\nVerifique a pasta assets/ e src/shaders/.");
        fprintf(stderr, "[KERNEL] ERRO: Recursos não carregados\n");
        return -1;
    }
    
    // Ajuste de resolução
    int w, h;
    glfwGetFramebufferSize((GLFWwindow*)g_window.window, &w, &h);
    resize_engine(w, h);
    
    // 6. LOOP PRINCIPAL
    lastFPSUpdate = KOVALSKIN_PLATFORM_GET_TIME();
    double previousTime = lastFPSUpdate;
    
    while (!KOVALSKIN_PLATFORM_WINDOW_SHOULD_CLOSE(&g_window)) {
        double currentTime = KOVALSKIN_PLATFORM_GET_TIME();
        float deltaTime = (float)(currentTime - previousTime);
        previousTime = currentTime;
        
        // FPS counter (KERNEL gerencia)
        KOVALSKIN_UPDATE_FPS();
        
        // Processar eventos e input (KERNEL gerencia)
        KOVALSKIN_PLATFORM_POLL_EVENTS(&g_window);
        KOVALSKIN_PROCESS_INPUT();
        
        // Atualizar e renderizar engine
        update_engine(deltaTime);
        render_engine();
        
        // Swap buffers
        KOVALSKIN_PLATFORM_SWAP_BUFFERS(&g_window);
    }
    
    // 7. FINALIZAÇÃO
    KOVALSKIN_PLATFORM_DESTROY(&g_window);
    return 0;
}