#ifndef SCENE_H
#define SCENE_H

// Estrutura de ponteiros de função: o "encaixe" da cena
typedef struct {
    void (*on_init)();               // Inicialização (Load assets)
    void (*on_update)(float delta);  // Lógica e Input
    void (*on_render)();             // Desenho OpenGL
    void (*on_exit)();               // Limpeza (Unload)
} SceneInterface;

#endif