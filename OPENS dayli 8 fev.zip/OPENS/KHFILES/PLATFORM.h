#ifndef PLATFORM_H
#define PLATFORM_H

#include <stdbool.h>
#include <stddef.h>

// --- Detecção de Categoria ---
#if defined(_WIN32) || defined(__linux__)
    #define SYS_PLATFORM_DESKTOP
#elif defined(__ANDROID__)
    #define SYS_PLATFORM_ANDROID
#elif defined(__ORBIS__) || defined(__PROSPERO__) || defined(_NX)
    #define SYS_PLATFORM_CONSOLE
#endif

typedef enum {
    KEY_UNKNOWN = 0,
    KEY_CIMA,      
    KEY_BAIXO,     
    KEY_CONFIRMAR, 
    KEY_VOLTAR,    
    KEY_SPACE,
    KEY_ESC,
    KEY_COUNT      
} KeyCode;

// Funções de Janela e Sistema

void KV_Platform_GetWindowSize(int* w, int* h);
void KV_Platform_CloseWindow();
void KV_Platform_SetVSync(bool enabled);
void KV_Platform_SetFullscreen(bool enabled);


void KV_Platform_UpdateViewport();
void KV_Platform_PollEvents();

void KV_Platform_Terminate();

// Funções de Memória e Telemetria
void KV_Platform_TrackAlloc(size_t size);
void KV_Platform_TrackFree(size_t size);
float KV_Platform_GetRAMUsage();
float KV_Platform_GetGameMemoryUsage();
float KV_Platform_GetTime();
void KV_Platform_SetWindowTitle(const char* title);

// Inicialização e Input
bool KV_Platform_WindowShouldClose();
bool KV_Platform_Init();
bool KV_Platform_CreateDefaultContext();// esse aqui e pra gerar a janela em contexto!
bool KV_Platform_IsKeyPressed(KeyCode key);
bool KV_Platform_IsKeyDown(KeyCode key);

#endif