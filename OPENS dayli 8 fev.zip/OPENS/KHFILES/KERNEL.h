#ifndef KERNEL_H
#define KERNEL_H

#include <stdbool.h>

/**
 * @brief Inicializa todos os módulos do motor na ordem correta.
 * (PLATFORM -> UNDKERNEL -> OPENGL -> SUBKERNEL)
 * @return 0 em caso de sucesso, ou código de erro negativo.
 */
int Kernel_Init();

/**
 * @brief Inicia o loop principal do jogo (Update e Render).
 * Esta função só retorna quando o jogo for fechado.
 */
void Kernel_Run();

/**
 * @brief Finaliza todos os módulos e libera a memória.
 * Deve ser chamado antes de encerrar o programa.
 */
void Kernel_Shutdown();

/**
 * @brief Retorna se o motor está rodando.
 */
bool Kernel_IsRunning();

/**
 * @brief Solicita que o motor pare de rodar no próximo frame.
 */
void Kernel_RequestExit();

#endif