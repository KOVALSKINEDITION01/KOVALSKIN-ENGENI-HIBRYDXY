#ifndef SUBKERNEL_H
#define SUBKERNEL_H
#include "SCENE.h"
#include <stdbool.h>

typedef enum {
    SCENE_BOOT,
    SCENE_MENU,
    SCENE_LOADING,
    SCENE_GAMEPLAY,
    SCENE_EXIT
} GameState;


void SubKernel_InitializeAll();
void SubKernel_SetActiveScene(SceneInterface* scene);
void SubKernel_UpdateLogic(float dt);
void SubKernel_RenderActiveScene();
void SubKernel_Cleanup();

#endif