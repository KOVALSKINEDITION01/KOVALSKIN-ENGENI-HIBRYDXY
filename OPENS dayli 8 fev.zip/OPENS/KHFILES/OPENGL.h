#ifndef OPENGL_H
#define OPENGL_H

#include <stdbool.h>

// Estrutura para gerenciar resoluções e proporção de tela
typedef struct {
    int width;
    int height;
    float aspect_ratio;
} ViewportInfo;

bool OpenGL_SetupContext();
void OpenGL_RenderFrame();
void OpenGL_SetViewport(int w, int h);
void OpenGL_PrepareFrame();
void OpenGL_FinishFrame();
void OpenGL_Cleanup();

#endif