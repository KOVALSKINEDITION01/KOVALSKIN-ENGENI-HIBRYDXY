#ifndef KH_FONT_H
#define KH_FONT_H

#include <stdbool.h>

typedef struct {
    unsigned int texture_id;
    void* data; 
} FontResource;

typedef enum {
    ANCHOR_TOP_LEFT,
    ANCHOR_CENTER,
    ANCHOR_BOTTOM_RIGHT
} TextAnchor;

void Font_SetColor(FontResource* font, float r, float g, float b);
bool Font_LoadFromMemory(FontResource* font, unsigned char* data, int data_len, float size);
void Font_Render(FontResource* font, const char* text, float x, float y);
float Font_GetTextWidth(FontResource* font, const char* text);
void Font_Unload(FontResource* font);
#endif