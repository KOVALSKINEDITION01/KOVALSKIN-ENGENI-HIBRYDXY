// INPUT.h
typedef enum {
    ACTION_NONE,
    ACTION_UP,
    ACTION_DOWN,
    ACTION_SELECT,
    ACTION_BACK
} InputAction;

typedef struct {
    float x, y;
    bool is_pressed;
} InputPointer;

// Esta função será implementada diferentemente para cada plataforma
InputAction Get_Current_Action();
InputPointer Get_Pointer_State();