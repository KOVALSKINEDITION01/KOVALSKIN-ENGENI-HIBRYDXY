#ifndef UNDKERNEL_H
#define UNDKERNEL_H

#include <stdbool.h>

/**
 * @brief Estrutura que armazena os recursos detectados do hardware.
 * Isso ajuda o KERNEL a decidir o que o jogo pode ou não rodar.
 */
typedef struct {
    int gl_major;       // Ex: 4
    int gl_minor;       // Ex: 6
    bool is_high_end;   // Se a GPU suporta recursos avançados
    size_t system_ram;  // Memória disponível detectada
} HardwareSpecs;

void UNDKernel_Setup();
void UNDKernel_Bootstrap();

HardwareSpecs UNDKernel_GetSpecs();

#endif