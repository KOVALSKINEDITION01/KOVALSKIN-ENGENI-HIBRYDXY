#ifndef SHADER_MANAGER_H
#define SHADER_MANAGER_H

#include <stdbool.h>

typedef struct {
    unsigned int id;
    bool is_linked;
} ShaderProgram;

/**
 * @brief Carrega, compila e linka um Vertex e um Fragment Shader.
 * @param vert_path Caminho para o arquivo .vert
 * @param frag_path Caminho para o arquivo .frag
 */
ShaderProgram Shader_Create(const char* vert_path, const char* frag_path);

/**
 * @brief Ativa o shader para uso no pipeline do OpenGL.
 */
void Shader_Bind(ShaderProgram program);

/**
 * @brief Deleta o programa da memória da GPU.
 */
void Shader_Delete(ShaderProgram program);

#endif