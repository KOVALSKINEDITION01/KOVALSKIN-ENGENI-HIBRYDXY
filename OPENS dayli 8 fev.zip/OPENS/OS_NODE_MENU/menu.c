/* =============================================================================
   SISTEMA: KOVALSKIN EMBREX
   MÓDULO:  menu.c
   DESCRIÇÃO: Cena de menu elegante com sistema de partículas (Folhas).
   ============================================================================= */

#include <glad/glad.h>
#include "KHFILES/SCENE.h"
#include "KHFILES/PLATFORM.h"
#include "KHFILES/SUBKERNEL.h"
#include "KHFILES/FONT.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h> 
#include <time.h>   

#define MAX_LEAVES 128

// Recursos externos
extern unsigned char assets_fonts_kovalskin_ttf[];
extern unsigned int assets_fonts_kovalskin_ttf_len;

// --- ESTRUTURAS ---
typedef enum { 
    MENU_STATE_MAIN, 
    MENU_STATE_OPTIONS 
} MenuState;

typedef struct {
    float x, y;
    float speed_y;
    float phase;
    float rotation;
    float rot_speed;
    bool active;
} Leaf;

// --- VARIÁVEIS ESTÁTICAS ---
static MenuState os_menu_current_state = MENU_STATE_MAIN;
static FontResource os_menu_font;
static int os_menu_selected_index = 0;
static float os_menu_timer = 0.0f;
static Leaf os_menu_leaves[MAX_LEAVES];

// Configurações estéticas
static const float MENU_PULSE_SPEED = 4.0f; 
static const float MENU_PULSE_FORCE = 0.02f;

// --- DADOS DAS OPÇÕES ---
static const char* main_options[] = {"START MISSION", "SYSTEM CONFIG", "TERMINATE"};
static bool opt_vsync = true;      
static bool opt_fullscreen = false;
static const char* config_labels[] = {"VSYNC: ", "DISPLAY: ", "RETURN"};

// --- TELEMETRIA ---
#ifdef SYS_PLATFORM_DESKTOP
    static float os_menu_telemetry_timer = 0.0f;
    static int   os_menu_fps_count = 0;
    static int   os_menu_fps_display = 0;
    static char  os_menu_fps_str[32] = "FPS: 0";
    static char  os_menu_ram_str[64] = "SYS: 0MB | GAME: 0MB";
#endif

// --- LÓGICA DE PARTÍCULAS ---

static void InitLeaves() {
    int w, h;
    KV_Platform_GetWindowSize(&w, &h);
    srand((unsigned int)time(NULL)); // Semente aleatória

    for (int i = 0; i < MAX_LEAVES; i++) {
        os_menu_leaves[i].x = (float)(rand() % w);
        os_menu_leaves[i].y = (float)(rand() % h);
        os_menu_leaves[i].speed_y = 40.0f + (rand() % 60);
        os_menu_leaves[i].phase = (float)(rand() % 100) / 10.0f;
        os_menu_leaves[i].rot_speed = (float)(rand() % 5);
        os_menu_leaves[i].active = true;
    }
}

// --- LÓGICA INTERNA ---

static void OS_MENU_Internal_Init() {
    printf("[OS_NODE_MENU] Inicializando Sistema de Menu...\n");
    Font_LoadFromMemory(&os_menu_font, assets_fonts_kovalskin_ttf, assets_fonts_kovalskin_ttf_len, 38.0f);
    
    os_menu_selected_index = 0;
    os_menu_current_state = MENU_STATE_MAIN;
    os_menu_timer = 0.0f;

    InitLeaves(); // Inicializa as folhas
}

static void OS_MENU_Internal_Update(float dt) {
    os_menu_timer += dt;
    
    #ifdef SYS_PLATFORM_DESKTOP
        os_menu_telemetry_timer += dt; 
        os_menu_fps_count++;
        if (os_menu_telemetry_timer >= 1.0f) {
            os_menu_fps_display = os_menu_fps_count;
            os_menu_fps_count = 0;
            os_menu_telemetry_timer = 0.0f;
            snprintf(os_menu_fps_str, sizeof(os_menu_fps_str), "FPS: %d", os_menu_fps_display);
            float sys_ram = KV_Platform_GetRAMUsage();
            float game_ram = KV_Platform_GetGameMemoryUsage();
            snprintf(os_menu_ram_str, sizeof(os_menu_ram_str), "SYS: %.1f MB | GAME: %.1f MB", sys_ram, game_ram);
        }
    #endif

    // --- NAVEGAÇÃO ---
    int max_idx = 2;
    if (KV_Platform_IsKeyPressed(KEY_BAIXO)) {
        os_menu_selected_index = (os_menu_selected_index + 1 > max_idx) ? 0 : os_menu_selected_index + 1;
    } 
    else if (KV_Platform_IsKeyPressed(KEY_CIMA)) {
        os_menu_selected_index = (os_menu_selected_index - 1 < 0) ? max_idx : os_menu_selected_index - 1;
    }

    // --- SELEÇÃO ---
    if (KV_Platform_IsKeyPressed(KEY_CONFIRMAR)) {
        if (os_menu_current_state == MENU_STATE_MAIN) {
            switch(os_menu_selected_index) {
                case 0: printf("Iniciando...\n"); break;
                case 1: os_menu_current_state = MENU_STATE_OPTIONS; os_menu_selected_index = 0; break;
                case 2: KV_Platform_CloseWindow(); break;
            }
        } 
        else {
            switch(os_menu_selected_index) {
                case 0: opt_vsync = !opt_vsync; KV_Platform_SetVSync(opt_vsync); break;
                case 1: opt_fullscreen = !opt_fullscreen; KV_Platform_SetFullscreen(opt_fullscreen); break;
                case 2: os_menu_current_state = MENU_STATE_MAIN; os_menu_selected_index = 1; break;
            }
        }
    }

    // --- ATUALIZAÇÃO DAS FOLHAS (COM DELTA TIME) ---
    int w, h;
    KV_Platform_GetWindowSize(&w, &h);
    
    for (int i = 0; i < MAX_LEAVES; i++) {
        // 1. Movimento Vertical: Velocidade (pixels/seg) * Tempo
        os_menu_leaves[i].y += os_menu_leaves[i].speed_y * dt;

        // 2. Movimento Horizontal: Onda senoidal * Força da oscilação * dt
        // O os_menu_timer já acumula o dt, então o balanço fica constante.
        float wave = sinf(os_menu_timer * 2.0f + os_menu_leaves[i].phase);
        os_menu_leaves[i].x += wave * 50.0f * dt; 
        
        // 3. Reset: Se sair da tela, volta para o topo
        if (os_menu_leaves[i].y > h + 20) {
            os_menu_leaves[i].y = -40.0f;
            os_menu_leaves[i].x = (float)(rand() % w);
            // Re-sorteia a velocidade para não caírem todas iguais
            os_menu_leaves[i].speed_y = 60.0f + (rand() % 100);
        }
    }
}

static void OS_MENU_Internal_Render() {
    glClearColor(0.005f, 0.005f, 0.01f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    
    int w, h;
    KV_Platform_GetWindowSize(&w, &h);

    // --- RENDERIZAR PARTÍCULAS (ATRAS DO MENU) ---
    for (int i = 0; i < MAX_LEAVES; i++) {
        // Cores outonais: mistura de laranja, marrom e verde seco
        float r = 0.4f + (i % 3) * 0.1f;
        float g = 0.25f + (i % 2) * 0.05f;
        Font_SetColor(&os_menu_font, r, g, 0.1f);
        Font_Render(&os_menu_font, "~", os_menu_leaves[i].x, os_menu_leaves[i].y);
    }

    // --- TELEMETRIA ---
    #ifdef SYS_PLATFORM_DESKTOP
        Font_SetColor(&os_menu_font, 0.2f, 0.4f, 0.2f);
        Font_Render(&os_menu_font, os_menu_fps_str, 25, 40);
        Font_Render(&os_menu_font, os_menu_ram_str, 25, 75);
    #endif

    // --- RENDERIZAR MENU (CANTO INFERIOR ESQUERDO) ---
    float margin_left = 60.0f;
    float margin_bottom = 80.0f;
    float spacing = 55.0f;
    
    for (int i = 0; i < 3; i++) {
        char buffer[128];
        bool is_selected = (i == os_menu_selected_index);
        
        if (os_menu_current_state == MENU_STATE_MAIN) {
            snprintf(buffer, sizeof(buffer), "%s", main_options[i]);
        } else {
            if (i == 0)      snprintf(buffer, sizeof(buffer), "%s%s", config_labels[i], opt_vsync ? "ACTIVE" : "DISABLED");
            else if (i == 1) snprintf(buffer, sizeof(buffer), "%s%s", config_labels[i], opt_fullscreen ? "FULLSCREEN" : "WINDOWED");
            else             snprintf(buffer, sizeof(buffer), "%s", config_labels[i]);
        }

        float py = (h - margin_bottom) - ((2 - i) * spacing);
        float px = margin_left + (is_selected ? 15.0f : 0.0f);

        if (is_selected) {
            Font_SetColor(&os_menu_font, 1.0f, 1.0f, 1.0f);
            char decorated_txt[150];
            snprintf(decorated_txt, sizeof(decorated_txt), "> %s", buffer);
            Font_Render(&os_menu_font, decorated_txt, px, py);
        } else {
            Font_SetColor(&os_menu_font, 0.35f, 0.4f, 0.45f);
            Font_Render(&os_menu_font, buffer, px, py);
        }
    }
}

static void OS_MENU_Internal_Exit() {
    printf("[OS_NODE_MENU] Descarregando...\n");
    Font_Unload(&os_menu_font);
}

SceneInterface OS_NODE_MENU = {
    OS_MENU_Internal_Init,
    OS_MENU_Internal_Update,
    OS_MENU_Internal_Render,
    OS_MENU_Internal_Exit
};