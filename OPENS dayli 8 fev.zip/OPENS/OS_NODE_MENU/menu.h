#ifndef MENU_H
#define MENU_H

#include "KHFILES/SCENE.h"


extern SceneInterface OS_Node_Menu;

#endif