/* =============================================================================
   SISTEMA: KOVALSKIN EMBREX
   MÓDULO:  KERNEL.c
   DESCRIÇÃO: Ponto de entrada e coordenação central dos subsistemas.
   ============================================================================= */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "KHFILES/KERNEL.h"
#include "KHFILES/PLATFORM.h"
#include "KHFILES/OPENGL.h"
#include "KHFILES/SUBKERNEL.h"
#include "KHFILES/UNDKERNEL.h"
#include "KHFILES/fonts_data.h"

// -----------------------------------------------------------------------------
// [ESTRUTURAS E ESTADOS GLOBAIS]
// -----------------------------------------------------------------------------
typedef struct {
    bool is_running;
    const char* engine_version;
} KernelManager;
static KernelManager g_kernel = { false, "1.0.0-void-Linux" };

// =============================================================================
// CATEGORIA: GERENCIAMENTO DE CICLO DE VIDA
// =============================================================================

void KV_Update_Performance_Stats() {
    // Variáveis estáticas mantêm o valor entre as chamadas da função
    static double last_update_time = 0.0;
    static int frame_count = 0;
    
    double current_time = KV_Platform_GetTime(); // Sua função que retorna glfwGetTime()
    double delta_time = current_time - last_update_time;
    frame_count++;
    
    // Atualiza a cada 1 segundo
    if (delta_time >= 1.0) {
        double fps = (double)frame_count / delta_time;
        double ms_per_frame = 1000.0 / fps;
        
        char title[128];
        snprintf(title, sizeof(title), 
                 "Kovalskin Edition | FPS: %.1f | %.3f ms", 
                 fps, ms_per_frame);
        
        KV_Platform_SetWindowTitle(title);
        
        // Reseta para o próximo ciclo
        frame_count = 0;
        last_update_time = current_time;
    }
}

/**
 * @brief Inicializa todos os módulos na ordem correta de dependência.
 * @return 0 em sucesso, -1 em falha fatal.
 */



int Kernel_Init() {
    printf("[KERNEL] Iniciando sistemas (Versao %s)...\n", g_kernel.engine_version);
    // 1. Camada de Abstração de SO
    if (!KV_Platform_Init()) {
        fprintf(stderr, "[FATAL] Falha ao inicializar PLATFORM.\n");
        return -1;
    }
    if (!KV_Platform_CreateDefaultContext()) {
        printf("[KERNEL] Erro ao criar contexto nativo!\n");
        return -1; 
    }
    // 2. Hardware e Backend Gráfico
    UNDKernel_Setup();
    if (!OpenGL_SetupContext()) {
        fprintf(stderr, "[FATAL] Falha ao criar contexto OPENGL.\n");
        return -1;
    }
    UNDKernel_Bootstrap();
    // 3. Lógica de Alto Nível
    SubKernel_InitializeAll();
    g_kernel.is_running = true;
    return 0;
}

/**
 * @brief Loop principal de execução (Frame Loop).
 */

void Kernel_Run() {
    float lastTime = KV_Platform_GetTime(); 
    while (!KV_Platform_WindowShouldClose()) {
        // --- Sincronização de Tempo ---
        float currentTime = KV_Platform_GetTime();
        float dt = currentTime - lastTime;
        lastTime = currentTime;
        KV_Update_Performance_Stats();
        // --- Entrada e Janela ---
        KV_Platform_PollEvents();
        KV_Platform_UpdateViewport();
        // --- Atualização de Lógica (Nodes) ---
        SubKernel_UpdateLogic(dt);
        // --- Pipeline de Renderização ---
        OpenGL_PrepareFrame();         // Limpa buffers
        SubKernel_RenderActiveScene(); // Desenha Node atual
        OpenGL_FinishFrame();          // Swap Buffers
    }
}

/**
 * @brief Finalização limpa e liberação de memória.
 */

void Kernel_Shutdown() {
    printf("[KERNEL] Encerrando motor e limpando memoria...\n");
    SubKernel_Cleanup();
    OpenGL_Cleanup();
    KV_Platform_Terminate();
}

// =============================================================================
// CATEGORIA: ENTRY POINT (C STANDARD)
// =============================================================================

int main(int argc, char* argv[]) {
    (void)argc; (void)argv; // Silencia parâmetros não usados
    if (Kernel_Init() != 0) {
        return EXIT_FAILURE;
    }
    Kernel_Run();
    Kernel_Shutdown();
    return EXIT_SUCCESS;
}