/* =============================================================================
   MÓDULO:  SUBKERNEL.c
   DESCRIÇÃO: Gerenciador de cenas modular e máquina de estados.
   ============================================================================= */

#include "KHFILES/SUBKERNEL.h"
#include "KHFILES/SCENE.h"
#include <stdio.h>
#include <stdlib.h>

// -----------------------------------------------------------------------------
// [ESTADO DO MÓDULO]
// -----------------------------------------------------------------------------
extern SceneInterface OS_NODE_LOGO; 
static SceneInterface* current_scene = NULL;

// =============================================================================
// CATEGORIA: GERENCIAMENTO DE CENAS (STATE MACHINE)
// =============================================================================

/**
 * @brief Realiza a transição segura entre dois nós de execução.
 */
void SubKernel_SetActiveScene(SceneInterface* scene) {
    if (!scene) return;

    // Finaliza cena anterior se existir
    if (current_scene && current_scene->on_exit) {
        current_scene->on_exit();
    }

    current_scene = scene;

    // Inicializa nova cena
    if (current_scene && current_scene->on_init) {
        current_scene->on_init();
    }
}

/**
 * @brief Alias para SetActiveScene (Compatibilidade).
 */
void SubKernel_SetScene(SceneInterface* scene) {
    SubKernel_SetActiveScene(scene);
}

// =============================================================================
// CATEGORIA: EXECUÇÃO POR FRAME
// =============================================================================

void SubKernel_InitializeAll() {
    printf("[SUBKERNEL] Gerenciador de Cenas Modular Ativo.\n");
    SubKernel_SetActiveScene(&OS_NODE_LOGO);
}

void SubKernel_UpdateLogic(float dt) {
    if (current_scene && current_scene->on_update) {
        current_scene->on_update(dt);
    }
}

void SubKernel_RenderActiveScene() {
    if (current_scene && current_scene->on_render) {
        current_scene->on_render();
    }
}

void SubKernel_RenderCurrentScene() {
    SubKernel_RenderActiveScene();
}

// =============================================================================
// CATEGORIA: LIMPEZA
// =============================================================================

void SubKernel_Cleanup() {
    if (current_scene && current_scene->on_exit) {
        current_scene->on_exit();
    }
    printf("[SUBKERNEL] Recursos limpos.\n");
}