/* =============================================================================
   MÓDULO:  UNDKERNEL.c
   DESCRIÇÃO: Análise de Hardware e Bootstrap de baixo nível.
   ============================================================================= */

#ifndef UNDKERNEL_H
#define UNDKERNEL_H

#include <stdio.h>
#include <stdbool.h>

// -----------------------------------------------------------------------------
// [SETOR: DEFINIÇÃO DE HARDWARE]
// -----------------------------------------------------------------------------
typedef struct {
    int system_ram;
    int gl_major;
    int gl_minor;
    bool is_high_end;
} HardwareSpecs;

// =============================================================================
// CATEGORIA: INTERFACE DE SETUP
// =============================================================================

/**
 * @brief Configura as premissas básicas de hardware.
 */
void UNDKernel_Setup() {
    printf("[UND] Inicializando Setup de Hardware...\n");
}

/**
 * @brief Executa o "pontapé inicial" dos recursos de hardware.
 * @return true se o hardware for compatível, false caso contrário.
 */
bool UNDKernel_Bootstrap() {
    printf("[UND] Bootstrap concluido.\n");
    return true;
}

// =============================================================================
// CATEGORIA: CONSULTA DE DADOS (GETTERS)
// =============================================================================

/**
 * @brief Obtém as especificações detectadas do sistema.
 */
HardwareSpecs UNDKernel_GetSpecs() {
    HardwareSpecs specs = {0};
    specs.system_ram = 512; // Exemplo de detecção estática
    return specs;
}

#endif