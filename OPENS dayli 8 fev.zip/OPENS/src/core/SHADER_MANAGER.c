/* =============================================================================
   MÓDULO:  SHADER_MANAGER.c
   DESCRIÇÃO: Compilação e injeção de headers GLSL dinâmicos.
   ============================================================================= */

#include "SHADER_MANAGER.h"
#include "PLATFORM.h"
#include <glad/glad.h>
#include <stdio.h>
#include <stdlib.h>

// =============================================================================
// CATEGORIA: UTILITÁRIOS INTERNOS
// =============================================================================

/**
 * @brief Retorna o cabeçalho de versão baseado na plataforma definida no Build.
 */
const char* GetGLSLVersionHeader() {
    #if defined(SYS_PLATFORM_DESKTOP)
        return "#version 460 core\n";
    #elif defined(SYS_PLATFORM_ANDROID)
        return "#version 300 es\nprecision mediump float;\n";
    #endif
    return "";
}

// =============================================================================
// CATEGORIA: INTERFACE PÚBLICA (API)
// =============================================================================

/**
 * @brief Cria, compila e linka um Shader Program completo.
 */
ShaderProgram Shader_Create(const char* vert_path, const char* frag_path) {
    ShaderProgram program = {0, false};
    
    // TODO: Implementar leitura de arquivo real
    const char* raw_vert_code = "void main() { gl_Position = vec4(0.0); }"; 
    
    // Injeção de Versão (Cross-Platform)
    const char* version = GetGLSLVersionHeader();
    const char* final_source[2] = { version, raw_vert_code };

    unsigned int vertex = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertex, 2, final_source, NULL);
    glCompileShader(vertex);

    // Linkagem do programa
    program.id = glCreateProgram();
    glAttachShader(program.id, vertex);
    glLinkProgram(program.id);
    
    program.is_linked = true;
    return program;
}