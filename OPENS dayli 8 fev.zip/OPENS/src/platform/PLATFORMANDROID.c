#include "KHFILES/PLATFORM.h"
#include <GLFW/glfw3.h>
#include <stdio.h>

// --- SETOR: ESTADO PRIVADO DO MÓDULO ---
static GLFWwindow* g_window = NULL;
static bool g_key_states[KEY_COUNT] = { false };

/**
 * Traduz as teclas do GLFW para o vocabulário da sua Engine.
 */
static int MapGLFWToEngine(int glfwKey) {
    switch (glfwKey) {
        // SETAS
        case GLFW_KEY_UP:        return KEY_CIMA;
        case GLFW_KEY_DOWN:      return KEY_BAIXO;
        
        // AÇÕES
        case GLFW_KEY_ENTER:     return KEY_CONFIRMAR;
        case GLFW_KEY_SPACE:     return KEY_CONFIRMAR;
        
        case GLFW_KEY_ESCAPE:    return KEY_VOLTAR;
        case GLFW_KEY_BACKSPACE: return KEY_VOLTAR;

        default: return KEY_UNKNOWN;
    }
}

/**
 * Função chamada pelo GLFW sempre que uma tecla muda de estado.
 */
static void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    int engineKey = MapGLFWToEngine(key);
    
    if (engineKey != KEY_UNKNOWN) {
        if (action == GLFW_PRESS)   g_key_states[engineKey] = true;
        if (action == GLFW_RELEASE) g_key_states[engineKey] = false;
    }
}

// --- SETOR: IMPLEMENTAÇÃO DA INTERFACE (PLATFORM.h) ---

bool Platform_Init() {
    if (!glfwInit()) return false;

    // Configurações para OpenGL 4.6 (Core Profile) no Ubuntu
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    g_window = glfwCreateWindow(1280, 720, "Motor Modular - KHFILES Ativo", NULL, NULL);
    if (!g_window) {
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(g_window);
    
    // Vincula a nossa função de captura ao GLFW
    glfwSetKeyCallback(g_window, KeyCallback);

    return true;
}

void Platform_PollEvents() {
    glfwPollEvents();
}

bool Platform_IsKeyDown(KeyCode key) {
    if (key < 0 || key >= KEY_COUNT) return false;
    return g_key_states[key];
}

bool Platform_WindowShouldClose() {
    return glfwWindowShouldClose(g_window);
}

void Platform_Terminate() {
    if (g_window) glfwDestroyWindow(g_window);
    glfwTerminate();
}