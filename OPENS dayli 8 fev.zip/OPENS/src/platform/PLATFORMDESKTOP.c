#include "KHFILES/PLATFORM.h"
#ifdef SYS_PLATFORM_DESKTOP
#include <GLFW/glfw3.h>
#include <stdio.h>

// Usaremos apenas g_window para evitar confusão
static GLFWwindow* g_window = NULL;
static bool last_key_state[KEY_COUNT] = {0};
static size_t g_game_allocated_mem = 0;


#ifdef _WIN32
    #include <windows.h>
    #include <psapi.h>
#else
    #include <unistd.h>
#endif


bool KV_Platform_Init() {
    if (!glfwInit()) {
        fprintf(stderr, "[PLATFORM] Erro ao inicializar GLFW\n");
        return false;
    }
    printf("[PLATFORM] GLFW inicializado com sucesso.\n");
    return true;
}


bool KV_Platform_IsKeyDown(KeyCode key) {
    if (!g_window) return false;
    
    int glfwKey = 0;
    switch(key) {
        case KEY_CIMA:      glfwKey = GLFW_KEY_UP; break;    
        case KEY_BAIXO:     glfwKey = GLFW_KEY_DOWN; break; 
        case KEY_CONFIRMAR: glfwKey = GLFW_KEY_ENTER; break;
        case KEY_SPACE:     glfwKey = GLFW_KEY_SPACE; break;
        case KEY_ESC:       glfwKey = GLFW_KEY_ESCAPE; break;
        default: return false;
    }
    
    return glfwGetKey(g_window, glfwKey) == GLFW_PRESS;
}

bool KV_Platform_IsKeyPressed(KeyCode key) {
    bool current_state = KV_Platform_IsKeyDown(key);
    bool pressed = (current_state && !last_key_state[key]);
    //static bool states[KEY_COUNT] = {0};
    last_key_state[key] = current_state;
    
    return pressed;
}
bool KV_Platform_WindowShouldClose() { 
    return g_window ? glfwWindowShouldClose(g_window) : true; 
}

bool KV_Platform_CreateDefaultContext() {
    g_window = glfwCreateWindow(1280, 720, "Kovalskin Engine", NULL, NULL);
    if (!g_window) return false;

    // SEM ESSA LINHA DÁ SEGFAULT NO FONT_LOAD:
    glfwMakeContextCurrent(g_window);
    glfwSwapInterval(1); 
    
    return true;
}




float KV_Platform_GetGameMemoryUsage() {
    return (float)(g_game_allocated_mem / (1024.0f * 1024.0f));
}


float KV_Platform_GetTime() {
    return (float)glfwGetTime();
}


float KV_Platform_GetRAMUsage() {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS_EX pmc;
    if (GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc))) {
        return (float)(pmc.WorkingSetSize / (1024.0f * 1024.0f));
    }
    return 0.0f;
#else
    // Linux/Ubuntu - Pegando o RSS (Memória Real)
    FILE* file = fopen("/proc/self/statm", "r");
    if (!file) return 0.0f;
    
    long vmsize = 0; // Memória Virtual (o que estava dando 1GB)
    long rss = 0;    // Memória Real (o que o Gerenciador mostra)
    
    // fscanf vai ler o primeiro número (vmsize) e o segundo (rss)
    if (fscanf(file, "%ld %ld", &vmsize, &rss) < 2) { 
        fclose(file); 
        return 0.0f; 
    }
    fclose(file);
    
    // O valor no statm é dado em "páginas". Precisamos converter para bytes.
    long pageSize = sysconf(_SC_PAGESIZE);
    float rss_mb = (float)((rss * pageSize) / (1024.0f * 1024.0f));
    
    return rss_mb;
#endif
}

void* KV_Platform_GetWindowHandle() { 
    return (void*)g_window; 
}

void KV_Platform_GetWindowSize(int* w, int* h) {
    if (g_window) {
        glfwGetFramebufferSize(g_window, w, h);
    }
    // muito importante essa bagaca
    else {
        *w = 800; *h = 600; // Fallback caaso de uma merda bem grande mesmo.
    }
}



void KV_Platform_CloseWindow() {
    if (g_window) {
        glfwSetWindowShouldClose(g_window, GLFW_TRUE);
    }
}
void KV_Platform_SetFullscreen(bool enabled) {
    if (!g_window) return;

    if (enabled) {
        // Pega o monitor principal e a resolução nativa dele
        GLFWmonitor* monitor = glfwGetPrimaryMonitor();
        const GLFWvidmode* mode = glfwGetVideoMode(monitor);
        glfwSetWindowMonitor(g_window, monitor, 0, 0, mode->width, mode->height, mode->refreshRate);
    } else {
        // Volta para o modo janela (centralizado como exemplo)
        glfwSetWindowMonitor(g_window, NULL, 100, 100, 800, 600, 0);
    }
}
void KV_Platform_UpdateViewport() {
    if (g_window) {
        int width, height;
        glfwGetFramebufferSize(g_window, &width, &height);
        glViewport(0, 0, width, height);
    }
}

void KV_Platform_SetWindowTitle(const char* title) {
    // Substitua 'g_window' pelo nome da variável global da sua janela no PLATFORMDESKTOP.c
    if (g_window) { 
        glfwSetWindowTitle(g_window, title);
    }
}

void KV_Platform_SyncInput() {
}

void KV_Platform_SetVSync(bool enabled) {
    glfwSwapInterval(enabled ? 1 : 0);
    printf("[PLATFORM] VSync alterado para: %s\n", enabled ? "ON" : "OFF");
}
void KV_Platform_PollEvents() { 
    glfwPollEvents(); 
}

void KV_Platform_SwapBuffers() {
    if (g_window) glfwSwapBuffers(g_window);
}

void KV_Platform_TrackAlloc(size_t size) { g_game_allocated_mem += size; }
void KV_Platform_TrackFree(size_t size)  { g_game_allocated_mem -= size; }

void KV_Platform_Terminate() {
    if (g_window) {
        glfwDestroyWindow(g_window);
        g_window = NULL;
    }
    glfwTerminate();
    printf("[PLATFORM] GLFW encerrado.\n");
}

#endif