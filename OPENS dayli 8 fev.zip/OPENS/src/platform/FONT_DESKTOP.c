#include "KHFILES/FONT.h"
#include "KHFILES/PLATFORM.h"
#include <glad/glad.h>
#define STB_TRUETYPE_IMPLEMENTATION
#include "KHFILES/stb_truetype.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    float x0, y0, x1, y1;
    float s0, t0, s1, t1;
    float advance;
} Glyph;

typedef struct {
    unsigned int texture_id;
    unsigned int vao, vbo;
    unsigned int shader;
    Glyph glyphs[128];
    float color[3];
} FontInternal;

static const char* fVS = "#version 460 core\n"
"layout(location = 0) in vec4 vertex;\n"
"out vec2 TexCoords;\n"
"uniform mat4 projection;\n"
"void main() {\n"
"    gl_Position = projection * vec4(vertex.xy, 0.0, 1.0);\n"
"    TexCoords = vertex.zw;\n"
"}";

static const char* fFS = "#version 460 core\n"
"in vec2 TexCoords;\n"
"out vec4 color;\n"
"uniform sampler2D text;\n"
"uniform vec3 textColor;\n"
"void main() {\n"
"    vec4 sampled = vec4(1.0, 1.0, 1.0, texture(text, TexCoords).r);\n"
"    color = vec4(textColor, 1.0) * sampled;\n"
"}";

static void make_ortho(float* m, float left, float right, float bottom, float top, float zNear, float zFar) {
    memset(m, 0, sizeof(float) * 16);
    m[0] = 2.0f / (right - left);
    m[5] = 2.0f / (top - bottom);
    m[10] = -2.0f / (zFar - zNear);
    m[12] = -(right + left) / (right - left);
    m[13] = -(top + bottom) / (top - bottom);
    m[14] = -(zFar + zNear) / (zFar - zNear);
    m[15] = 1.0f;
}

void Font_SetColor(FontResource* font, float r, float g, float b) {
    if (!font || !font->data) return;
    FontInternal* internal = (FontInternal*)font->data;
    internal->color[0] = r;
    internal->color[1] = g;
    internal->color[2] = b;
}

// --- FUNÇÃO PARA CARREGAR DA MEMÓRIA (PORTABLE) ---
bool Font_LoadFromMemory(FontResource* font, unsigned char* data, int data_len, float size) {
    if (!font || !data) return false;
    (void)data_len; // Silencia aviso de não usado

    FontInternal* internal = (FontInternal*)malloc(sizeof(FontInternal));
    if (!internal) return false;
    memset(internal, 0, sizeof(FontInternal));

    unsigned char* bitmap = malloc(512 * 512);
    stbtt_bakedchar baked[96];
    
    // Processa os bytes que já estão no .h
    int result = stbtt_BakeFontBitmap(data, 0, size, bitmap, 512, 512, 32, 96, baked);
    if (result <= 0) {
        printf("[FONT] ERRO: Falha ao processar fonte da memoria.\n");
        free(bitmap); free(internal);
        return false;
    }

    glGenTextures(1, &internal->texture_id);
    glBindTexture(GL_TEXTURE_2D, internal->texture_id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, 512, 512, 0, GL_RED, GL_UNSIGNED_BYTE, bitmap);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    for(int i = 0; i < 96; i++) {
        int idx = i + 32;
        internal->glyphs[idx].advance = baked[i].xadvance;
        internal->glyphs[idx].s0 = baked[i].x0 / 512.0f;
        internal->glyphs[idx].t0 = baked[i].y0 / 512.0f;
        internal->glyphs[idx].s1 = baked[i].x1 / 512.0f;
        internal->glyphs[idx].t1 = baked[i].y1 / 512.0f;
        internal->glyphs[idx].x0 = baked[i].xoff;
        internal->glyphs[idx].y0 = baked[i].yoff;
        internal->glyphs[idx].x1 = baked[i].xoff + (baked[i].x1 - baked[i].x0);
        internal->glyphs[idx].y1 = baked[i].yoff + (baked[i].y1 - baked[i].y0);
    }

    unsigned int v = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(v, 1, &fVS, NULL); glCompileShader(v);
    unsigned int fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &fFS, NULL); glCompileShader(fs);
    internal->shader = glCreateProgram();
    glAttachShader(internal->shader, v); glAttachShader(internal->shader, fs);
    glLinkProgram(internal->shader);

    glGenVertexArrays(1, &internal->vao);
    glGenBuffers(1, &internal->vbo);
    glBindVertexArray(internal->vao);
    glBindBuffer(GL_ARRAY_BUFFER, internal->vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), 0);

    font->data = internal;
    free(bitmap); 
    printf("[FONT] Fonte carregada da MEMORIA (Modo Portable Ativo).\n");
    internal->color[0] = 1.0f;
    internal->color[1] = 1.0f;
    internal->color[2] = 1.0f;
    KV_Platform_TrackAlloc(512 * 512);
    return true;
}

// --- MANTEMOS O LOAD NORMAL PARA COMPATIBILIDADE ---
bool Font_Load(FontResource* font, const char* path, float size) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;

    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);

    unsigned char* buf = (unsigned char*)malloc(len);
    if(!buf) { 
        fclose(f); 
        return false; 
    }

    // Lemos o arquivo e guardamos o retorno para silenciar o warning do GCC
    size_t read_check = fread(buf, 1, len, f);
    (void)read_check; // Informa ao compilador que ignoramos o valor propositalmente

    fclose(f);

    // Repassa os bytes para a função de memória que já criamos
    bool res = Font_LoadFromMemory(font, buf, (int)len, size);
    
    free(buf);
    return res;
}

void Font_Render(FontResource* font, const char* text, float x, float y) {
    if (!font || !font->data) return;
    FontInternal* internal = (FontInternal*)font->data;

    int w, h;
    KV_Platform_GetWindowSize(&w, &h);
    glUseProgram(internal->shader);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    float proj[16];
    make_ortho(proj, 0, (float)w, (float)h, 0, -1, 1);
    glUniformMatrix4fv(glGetUniformLocation(internal->shader, "projection"), 1, GL_FALSE, proj);
    glUniform3f(glGetUniformLocation(internal->shader, "textColor"), 
                internal->color[0], internal->color[1], internal->color[2]);

    glBindTexture(GL_TEXTURE_2D, internal->texture_id);
    glBindVertexArray(internal->vao);

    float curX = x;
    while (*text) {
        if ((unsigned char)*text >= 32 && (unsigned char)*text < 128) {
            Glyph* g = &internal->glyphs[(int)*text];
            float xpos = curX + g->x0;
            float ypos = y + g->y0;
            float gw = g->x1 - g->x0;
            float gh = g->y1 - g->y0;
            float verts[6][4] = {
                {xpos, ypos+gh, g->s0, g->t1}, {xpos, ypos, g->s0, g->t0}, {xpos+gw, ypos, g->s1, g->t0},
                {xpos, ypos+gh, g->s0, g->t1}, {xpos+gw, ypos, g->s1, g->t0}, {xpos+gw, ypos+gh, g->s1, g->t1}
            };
            glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(verts), verts);
            glDrawArrays(GL_TRIANGLES, 0, 6);
            curX += g->advance;
        }
        text++;
    }
}

float Font_GetTextWidth(FontResource* font, const char* text) {
    if (!font || !font->data) return 0.0f;
    FontInternal* internal = (FontInternal*)font->data;
    float w = 0.0f;
    while (*text) {
        if ((unsigned char)*text >= 32 && (unsigned char)*text < 128)
            w += internal->glyphs[(int)*text].advance;
        text++;
    }
    return w;
}

void Font_Unload(FontResource* font) {
    if (font && font->data) {
        FontInternal* i = (FontInternal*)font->data;
        // ... deleta as coisas do OpenGL ...
        
        free(i); 
        font->data = NULL;

        KV_Platform_TrackFree(512 * 512); 
    }
}
