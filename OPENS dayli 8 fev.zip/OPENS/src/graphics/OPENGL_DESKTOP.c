/* =============================================================================
   MÓDULO:  OPENGL_DESKTOP.c
   DESCRIÇÃO: Implementação do Backend Gráfico para Desktop (OpenGL Core).
   ============================================================================= */

#include <stdbool.h>
#include <stdio.h>
#include "KHFILES/PLATFORM.h"

#ifdef SYS_PLATFORM_DESKTOP
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "KHFILES/OPENGL.h"
#include "KHFILES/UNDKERNEL.h"
#include "KHFILES/SUBKERNEL.h"

// =============================================================================
// CATEGORIA: INICIALIZAÇÃO E CONTEXTO
// =============================================================================

/**
 * @brief Carrega os ponteiros de função do OpenGL via GLAD.
 */
bool OpenGL_SetupContext() {
    printf("[DEBUG] Iniciando OpenGL_SetupContext...\n");
    
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        printf("[ERRO] Falha ao carregar GLAD!\n");
        return false;
    }
    return true;
}

// =============================================================================
// CATEGORIA: CONTROLE DE FRAME
// =============================================================================

/**
 * @brief Prepara o buffer para um novo desenho (Limpeza).
 */
void OpenGL_PrepareFrame() {
    glClearColor(0.01f, 0.01f, 0.02f, 1.0f); // Cor de fundo Navy Blue Escuro
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

/**
 * @brief Finaliza o desenho e troca os buffers (Swap).
 */
void OpenGL_FinishFrame() {
    GLFWwindow* window = glfwGetCurrentContext();
    if (window) {
        glfwSwapBuffers(window);
    }
}

/**
 * @brief Executa o pipeline completo de renderização de um frame.
 */
void OpenGL_RenderFrame() {
    OpenGL_PrepareFrame();
    SubKernel_RenderActiveScene(); // Chamada para o desenho da cena atual
    OpenGL_FinishFrame();
}

// =============================================================================
// CATEGORIA: FINALIZAÇÃO
// =============================================================================

void OpenGL_Cleanup() {
    printf("[OPENGL] Limpando recursos de renderizacao...\n");
}

#endif