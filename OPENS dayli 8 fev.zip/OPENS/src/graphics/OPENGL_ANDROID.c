#include "PLATFORM.h"

#ifdef SYS_PLATFORM_ANDROID
#include <glad/glad.h> // GLAD configurado para GLES
#include <EGL/egl.h>
#include "OPENGL.h"
#include "UNDKERNEL.h"
#include "SUBKERNEL.h"
#include <android/log.h>

bool OpenGL_SetupContext() {
    HardwareSpecs specs = UNDKernel_GetSpecs();
    
    // Lógica de inicialização do EGL/GLES específica do Android
    // ...
    
    if (!gladLoadGLES2Loader((GLADloadproc)eglGetProcAddress)) {
        __android_log_print(ANDROID_LOG_ERROR, "ENGINE", "Falha no GLAD ES");
        return false;
    }

    return true;
}

void OpenGL_RenderFrame() {
    // No Android, o SwapBuffers é feito via eglSwapBuffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    SubKernel_RenderCurrentScene();
    // eglSwapBuffers(display, surface);
}
#endif