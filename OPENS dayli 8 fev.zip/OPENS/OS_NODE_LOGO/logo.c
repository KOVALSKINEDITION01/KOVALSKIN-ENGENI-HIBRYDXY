/* =============================================================================
   SISTEMA: KOVALSKIN EMBREX
   MÓDULO:  logo.c
   DESCRIÇÃO: cena logo.
   ============================================================================= */
#include <glad/glad.h>
#include "KHFILES/SCENE.h"
#include "KHFILES/PLATFORM.h"
#include "KHFILES/OPENGL.h"
#include "KHFILES/SUBKERNEL.h"
#include "KHFILES/FONT.h"
#include <stdio.h>

extern SceneInterface OS_NODE_AVISO;
extern unsigned char assets_fonts_kovalskin_ttf[];
extern unsigned int assets_fonts_kovalskin_ttf_len;


//=============================================================================
//statics!!!!
//=============================================================================
static float logo_alpha = 1.0f;
static float timer = 0.0f;
static FontResource font_logo;
static const char* texto_logo = "KOVALSKIN EDITION";

void Logo_Init() {
    // O compilador vai procurar esses nomes lá no Kernel na hora de montar o jogo
Font_LoadFromMemory(&font_logo, assets_fonts_kovalskin_ttf, assets_fonts_kovalskin_ttf_len, 64.0f);
}

void Logo_Update(float dt) {
    timer += dt;

    // Aumentamos a velocidade para 2.0f (Fade Out mais rápido)
    // O fade começa aos 4 segundos e termina aos 4.5 segundos
    if (timer > 3.5f) {
        logo_alpha -= dt * 3.5f; 
        if (logo_alpha < 0.0f) logo_alpha = 0.0f;
    }

    if (timer > 5.0f) {
        SubKernel_SetActiveScene(&OS_NODE_AVISO); 
    }
}

// ESTA EH A FUNCAO QUE A INTERFACE USA
void Logo_Render() {
    // 1. O fundo clareia (de azul para branco)
    float bg_offset = 1.0f - logo_alpha;
    float bg_r = 0.01f + bg_offset;
    float bg_g = 0.01f + bg_offset;
    float bg_b = 0.05f + bg_offset;
    
    glClearColor(bg_r, bg_g, bg_b, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    int w, h;
    KV_Platform_GetWindowSize(&w, &h);
    
    float tw = Font_GetTextWidth(&font_logo, texto_logo);
    
    // CORREÇÃO: O texto deve permanecer BRANCO puro (1,1,1)
    // Ele vai "sumir" naturalmente porque o fundo está virando branco também.
    Font_SetColor(&font_logo, 1.0f, 1.0f, 1.0f);
    
    Font_Render(&font_logo, texto_logo, (w - tw) / 2.0f, h / 2.0f);
}


void Logo_Exit() {
    printf("[NODE_LOGO] Descarregando fonte...\n");
    Font_Unload(&font_logo);
}

SceneInterface OS_NODE_LOGO = {
    Logo_Init,
    Logo_Update,
    Logo_Render,
    Logo_Exit
};