/* =============================================================================
   SISTEMA: KOVALSKIN EMBREX
   MÓDULO:  aviso.c
   DESCRIÇÃO: Cena de aviso com Redimensionamento e Efeito de Fade In.
   ============================================================================= */

#include <glad/glad.h>
#include "KHFILES/SCENE.h"
#include "KHFILES/PLATFORM.h"
#include "KHFILES/FONT.h"
#include "KHFILES/SUBKERNEL.h"
#include <stdio.h>
#include <math.h>

static FontResource font_aviso;
static int last_h = 0;
static float fade_alpha = 0.0f;

extern SceneInterface OS_NODE_MENU;
extern unsigned char assets_fonts_kovalskin_ttf[];
extern unsigned int assets_fonts_kovalskin_ttf_len;

static const char* msg_aviso = "Este jogo e recomendado para maiores de 21 anos de idade!";
static const char* msg_instrucao = "Pressione [ESPACO] ou [ENTER] para confirmar";
static float blink_timer = 0.0f;
// -----------------------------------------------------------------------------
// [LÓGICA DE DIMENSIONAMENTO]
// -----------------------------------------------------------------------------
static void AdjustFontSize(int current_h) {
    if (current_h == last_h) return; 
    if (last_h != 0) Font_Unload(&font_aviso);

    float base_h = 600.0f;
    float base_size = 32.0f;
    float dynamic_size = (current_h / base_h) * base_size;

    if (dynamic_size < 12.0f) dynamic_size = 12.0f;

    Font_LoadFromMemory(&font_aviso, assets_fonts_kovalskin_ttf, assets_fonts_kovalskin_ttf_len, dynamic_size);
    last_h = current_h;
}

// -----------------------------------------------------------------------------
// [CICLO DE VIDA DO NODE]
// -----------------------------------------------------------------------------

void aviso_Init() {
    int w, h;
    KV_Platform_GetWindowSize(&w, &h);
    last_h = 0;
    fade_alpha = 0.0f; 
    blink_timer = 0.0f;
    AdjustFontSize(h);
}

void aviso_Update(float dt) {
    // Incrementa o Alpha baseado no Delta Time
    // 0.5f significa que levará 2 segundos para o fade completo (1.0 / 0.5 = 2)
    if (fade_alpha < 1.0f) {
        fade_alpha += dt * 0.9f; // Velocidade do Fade (ajuste aqui)
        if (fade_alpha > 1.0f) fade_alpha = 1.0f;
    }
    if (fade_alpha >= 1.0f) {
        blink_timer += dt; 
    }
    int w, h;
    KV_Platform_GetWindowSize(&w, &h);
    AdjustFontSize(h);

    if (KV_Platform_IsKeyDown(KEY_SPACE) || KV_Platform_IsKeyDown(KEY_CONFIRMAR)) {
        SubKernel_SetActiveScene(&OS_NODE_MENU); 
    }
}

void aviso_Render() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Fundo Branco
    glClear(GL_COLOR_BUFFER_BIT);

    int w, h;
    KV_Platform_GetWindowSize(&w, &h);

    // 1. Mensagem Principal (Branco -> Vermelho)
    float tw1 = Font_GetTextWidth(&font_aviso, msg_aviso);
    Font_SetColor(&font_aviso, 1.0f, 1.0f - fade_alpha, 1.0f - fade_alpha);
    Font_Render(&font_aviso, msg_aviso, (w - tw1) / 2.0f, h / 2.0f - (h * 0.05f));

    // 2. Instrução com Efeito Blink (Branco -> Preto -> Piscando)
    float tw2 = Font_GetTextWidth(&font_aviso, msg_instrucao);
    
    float instrucao_alpha = 1.0f - fade_alpha; // Fade In inicial (vai de 1.0 a 0.0 para ficar preto)

    // Se o fade principal já terminou (fade_alpha == 1.0), começamos o blink
    if (fade_alpha >= 1.0f) {
        // Agora usamos o blink_timer atualizado pelo dt!
        // Como o seno agora recebe tempo real, a velocidade 4.0f será constante
        float blink = (sinf(blink_timer * 4.0f) * 0.5f) + 0.5f;
        instrucao_alpha = blink * 0.4f; 
    }

    Font_SetColor(&font_aviso, instrucao_alpha, instrucao_alpha, instrucao_alpha);
    Font_Render(&font_aviso, msg_instrucao, (w - tw2) / 2.0f, h / 2.0f + (h * 0.1f));
}

void aviso_Exit() {
    Font_Unload(&font_aviso);
    last_h = 0;
}

SceneInterface OS_NODE_AVISO = {
    aviso_Init,
    aviso_Update,
    aviso_Render,
    aviso_Exit
};